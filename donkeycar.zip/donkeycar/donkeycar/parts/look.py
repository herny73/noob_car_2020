# -*- coding: utf-8 -*-
"""
Created on Mon Nov 16 18:48:53 2020

开发说明：希望在这里实现输入一个图片输出一个数字

@author: herny
"""

